export const LOADING = "LOADING"
export const SUCCESS = "SUCCESS"
export const PASSWORDERROR = "ERROR"