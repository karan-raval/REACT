export const SLOADING = "SLOADING"
export const SSUCCESS = "SSUCCESS"
export const SERROR = "SERROR"